---
title: about
date: 2017-09-22 09:26:03
comments: false
---
<blockquote class="blockquote-center">
迹晦光韬
不代表
豪情已折耗
拿得起当年勇
傲视群群雄
不足道
</blockquote>
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=448144319&auto=1&height=66"></iframe>
